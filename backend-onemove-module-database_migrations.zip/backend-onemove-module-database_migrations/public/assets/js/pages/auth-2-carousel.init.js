/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************************!*\
  !*** ./resources/js/pages/auth-2-carousel.init.js ***!
  \****************************************************/
$("#auth-review-carousel").owlCarousel({
  items: 1,
  loop: !1,
  margin: 16,
  nav: !1,
  dots: !0
});
/******/ })()
;