<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;

class ShipperController extends Controller
{

    public function numberVerification(Request $request)
    {

        $request->validate([
            'mobile_number' => 'required|unique:users,mobile_number|numeric',
        ]);
        return response()->json(['type' => 'New User'], 200);

    }

    public function register(Request $request)
    {

        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'code' => 'required',
            'mobile_number' => 'required|numeric|unique:users,mobile_number',
            'password' => 'required|confirmed|min:6',
        ]);

        $user = new User();
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->mobile_number = $request->mobile_number;
        $user->verification_code = $request->code;
        $user->verify_time_date = date('Y-m-d H:i:s');

        $user->save();
        $role = Role::where('name', 'Shipper')->first();
        $user->roles()->attach($role->id);

        $token = $user->createToken('nrjdpaok')->plainTextToken;

        return response()->json(['message' => 'User Registered Successfully', 'user' => $user, 'roles', $user->roles, 'token' => $token,], 200);
    }

}
