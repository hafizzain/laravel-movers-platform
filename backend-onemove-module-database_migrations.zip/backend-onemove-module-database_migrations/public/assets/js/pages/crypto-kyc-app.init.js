/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************************************!*\
  !*** ./resources/js/pages/crypto-kyc-app.init.js ***!
  \***************************************************/
$(document).ready(function () {
  $("#kyc-verify-wizard").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slide"
  });
});
/******/ })()
;