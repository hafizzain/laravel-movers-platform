/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************************************!*\
  !*** ./resources/js/pages/ecommerce-cart.init.js ***!
  \***************************************************/
$("input[name='demo_vertical']").TouchSpin({
  verticalbuttons: !0
});
/******/ })()
;