/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************************************!*\
  !*** ./resources/js/pages/jquery-knob.init.js ***!
  \************************************************/
$(function () {
  $(".knob").knob();
});
/******/ })()
;