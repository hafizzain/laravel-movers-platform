/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!**********************************************!*\
  !*** ./resources/js/pages/form-mask.init.js ***!
  \**********************************************/
$(document).ready(function () {
  $(".input-mask").inputmask();
});
/******/ })()
;