/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/js/pages/lightbox.init.js":
/*!*********************************************!*\
  !*** ./resources/js/pages/lightbox.init.js ***!
  \*********************************************/
/***/ (function() {

!function (e) {
  "use strict";

  e(".image-popup-vertical-fit").magnificPopup({
    type: "image",
    closeOnContentClick: !0,
    mainClass: "mfp-img-mobile",
    image: {
      verticalFit: !0
    }
  }), e(".image-popup-no-margins").magnificPopup({
    type: "image",
    closeOnContentClick: !0,
    closeBtnInside: !1,
    fixedContentPos: !0,
    mainClass: "mfp-no-margins mfp-with-zoom",
    image: {
      verticalFit: !0
    },
    zoom: {
      enabled: !0,
      duration: 300
    }
  }), e(".popup-gallery").magnificPopup({
    delegate: "a",
    type: "image",
    tLoading: "Loading image #%curr%...",
    mainClass: "mfp-img-mobile",
    gallery: {
      enabled: !0,
      navigateByImgClick: !0,
      preload: [0, 1]
    },
    image: {
      tError: '<a href="%url%">The image #%curr%</a> could not be loaded.'
    }
  }), e(".zoom-gallery").magnificPopup({
    delegate: "a",
    type: "image",
    closeOnContentClick: !1,
    closeBtnInside: !1,
    mainClass: "mfp-with-zoom mfp-img-mobile",
    image: {
      verticalFit: !0,
      titleSrc: function titleSrc(e) {
        return e.el.attr("title") + ' &middot; <a href="' + e.el.attr("data-source") + '" target="_blank">image source</a>';
      }
    },
    gallery: {
      enabled: !0
    },
    zoom: {
      enabled: !0,
      duration: 300,
      opener: function opener(e) {
        return e.find("img");
      }
    }
  }), e(".popup-youtube, .popup-vimeo, .popup-gmaps").magnificPopup({
    disableOn: 700,
    type: "iframe",
    mainClass: "mfp-fade",
    removalDelay: 160,
    preloader: !1,
    fixedContentPos: !1
  }), e(".popup-with-zoom-anim").magnificPopup({
    type: "inline",
    fixedContentPos: !1,
    fixedBgPos: !0,
    overflowY: "auto",
    closeBtnInside: !0,
    preloader: !1,
    midClick: !0,
    removalDelay: 300,
    mainClass: "my-mfp-zoom-in"
  }), e(".popup-with-move-anim").magnificPopup({
    type: "inline",
    fixedContentPos: !1,
    fixedBgPos: !0,
    overflowY: "auto",
    closeBtnInside: !0,
    preloader: !1,
    midClick: !0,
    removalDelay: 300,
    mainClass: "my-mfp-slide-bottom"
  }), e(".popup-form").magnificPopup({
    type: "inline",
    preloader: !1,
    focus: "#name",
    callbacks: {
      beforeOpen: function beforeOpen() {
        e(window).width() < 700 ? this.st.focus = !1 : this.st.focus = "#name";
      }
    }
  });
}.apply(this, [jQuery]);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/js/pages/lightbox.init.js"]();
/******/ 	
/******/ })()
;